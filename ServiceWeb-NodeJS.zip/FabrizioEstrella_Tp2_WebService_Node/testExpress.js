//on va chercher librairies
const express = require('express');
// instanceci librairie
const app = express();
// Quan tu passe par la route on recoit deux parametre

let chaineHTML 



// respond with "hello world" when a GET request is made to the homepage
app.get('/', (req, res) => {
    console.log('allo');
    res.send('hello world')
  });

// respond with "hello world" when a GET request is made to the homepage
// la route Produit Ceci est une deuxieme route cree pour Produit
// installer sur la route produit middleware ... 
app.get('/produit', (req, res, next) => {
    console.log('premier produit');
    //res.send('Allo le monde, voici mon produit');
    chaineHTML += "Allo le monde...";
    if(Math.random() > 0.5){
        next();
    }
    else
    {
        res.send("plus petit que 0.5");
    }
    

  });
  app.get('/produit', (req, res) => {
    console.log('premier produit');
    res.send(chaineHTML ,'Allo le monde, voici mon produit');
   

  });




// On ecoute sur quelle port
app.listen('8080', function (req, res){
    console.log('Allo le monde');
});