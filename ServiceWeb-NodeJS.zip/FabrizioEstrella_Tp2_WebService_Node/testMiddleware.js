//on va chercher librairies
const express = require('express');
// instanceci librairie
const app = express();
//Pour instancier le package installer de cors npm install cors
const cors = require('cors');
// Package body-parsr
const  bodyParser = require ('body-parser');
//gere l"authenfication de base
const auth = requite ('basic-aut');
app.use(cors());
app.use(bodyParser.json());

function authBasic (req,res, next){
    const usager = auth(req);
    // SI lusager est authentifier on utulise next()
    if (usager && usager.name == 'biero' && usager.pass == biero){
        next();
    }else{
        res.status(401).send('401');
    }

}



// Pour toute les method sur toute les routes fait Next()
app.all('*' , function (req, res, next){
    chaine = 'Allo' + (Math.random()*10);
    //res.send(chaine);
    next();
})

// On met le middleware AUTH sur tout les app.put
app.put ('*', authBasic);
app.post ('*', authBasic);
app.delete ('*', authBasic);

// Put
app.put('/biere', function (req, res){
    //Permet de voir ce quon envoi
    //Chaque route a son middleware
    //Pour lire les elements JSON qui retourne
    res.json(req.body);
})

// Route Biere
app.get("/biere", function(req,res){
    res.send('List des bieres');
})

// Route pour les details dune biere ( Regarder la documentation) utiliser params pour obtenier les details
app.get("/biere/:id_biere", function(req,res){
   res.send('Les details d"une biere' + req.params.id_biere) ;
})


// On ecoute sur quelle port
app.listen('8080', function (req, res){
    console.log('Allo le monde');
})