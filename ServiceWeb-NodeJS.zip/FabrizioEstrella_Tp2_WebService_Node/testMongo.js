const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const auth = require('basic-auth');
const app = express();
const mongo = require("mongodb");
const mongoclient = mongo.MongoClient;

app.use(cors());
app.use(bodyParser.json());

function authBasic(req, res, next){
    const usager = auth(req);
    if(usager && usager.name == 'biero' && usager.pass == 'biero'){
        next();
    }
    else{
        res.status(401).send("401");
    }


}

app.all("*", function(req, res, next){

    chaine = 'Allo '+ parseInt(Math.random()*10);
    next();
})
app.put("*", authBasic);
app.post("*", authBasic);
app.delete("*", authBasic);

app.put("/biere", function(req, res){ 
    mongoclient.connect("mongodb://127.0.0.1:27017", (err, db)=>{
        if(err){
            res.send("Erreur de connection");
            throw err;
        }
        let database = db.db("biero");
        let collection = database.collection("bieres");
        let uneBiere = req.body;
        uneBiere.date_ajout = new Date();
        uneBiere.commentaires = [];

        //Section MONGODB
        // https://www.mongodb.com/docs/manual/reference/method/db.collection.deleteOne/#mongodb-method-db.collection.deleteOne
        collection.insertOne(uneBiere, (err, db)=>{
            res.json({ok : true});        
        })

    })
    //res.json(req.body);
});

// Section POST DOIT COMPLETER

app.post ("/biere" , function (req, res) {

    //connection mongoDB
    mongoclient.connect("mongodb://127.0.0.1:27017", (err, db) =>{
        if(err){
            res.send('Erreur de connection');
            throw err;
        }
        let database = db.db("biero");
        let collection = database.collection("biere");
        let uneBiere = red.body;
        uneBiere.date_ajout = new Date();

        collection.insert(uneBiere, (err,db) => {
            res.json({ok:true})
        })
    })
});
// Section DELETE
app.delete ("/biere/:id_biere" , function (red, res) {
    //connection mongoDB
    mongoclient.connect("mongodb://127.0.0.1:27017", (err, db) =>{
        if(err){
            res.send('Erreur de connection');
            throw err;
        }
        let database = db.db("biero");
        let collection = database.collection("biere");
        let uneBiere = red.body;

        let id = req.params('id');
        collection.remove(  uneBiere, {_id  : id }, (err, resultat)=>{
            res.json(resultat);
        })
});



app.get("/biere", function(req, res){
    mongoclient.connect("mongodb://127.0.0.1:27017", (err, db)=>{
        if(err){
            res.send("Erreur de connection");
            throw err;
        }
        let database = db.db("biero");
        let collection = database.collection("bieres");
        collection.find().toArray((err, resultat)=>{
            resultat.forEach(element => {
                delete element.commentaires;
            });
            res.json(resultat);
        })

    })
    //res.send(chaine + "liste des bieres");
});
app.get("/biere/:id_biere", function(req, res, next){
    //res.send(chaine + "Les dÃ©tails d'une biere" + req.params.id_biere);
    mongoclient.connect("mongodb://127.0.0.1:27017", (err, db)=>{
        if(err){
            res.send("Erreur de connection");
            throw err;
        }
        let database = db.db("biero");
        let collection = database.collection("bieres");
        collection.findOne({_id : new mongo.ObjectId(req.params.id_biere)}, (err, resultat)=>{
            res.json(resultat);
        });

    })
});

app.listen('8080', function(req, res){
    console.log("Serveur dÃ©marrÃ©");
});

})